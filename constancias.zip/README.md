# CONSTANCIAS BOT V2

This is a small piece of software that creates a course completion certificate pdf and sends it through email to our clients. I created this to save me time and to avoid doing repetitive work.
